    // while(1){

    //     if(ferror(fp)){
    //         printf("file write error");
    //         exit(1);
    //     }
    //     if(feof(fp)) break;

    // }