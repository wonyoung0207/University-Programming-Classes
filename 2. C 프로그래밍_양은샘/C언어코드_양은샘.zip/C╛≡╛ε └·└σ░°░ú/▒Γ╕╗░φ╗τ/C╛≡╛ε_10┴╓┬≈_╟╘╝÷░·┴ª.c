#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>


void mystrcat(char *a,char *b, char *p){
    while(*a){
        *p = *a;
        p++;
        a++;
    }
    while(*b){
        *p = *b;
        p++;
        b++;
    }
    *p = '\0';
}


int main(int argc, char *argv[])
{
    char plus[50];

    printf("20155137 �ȿ���\n");

    mystrcat(argv[1],argv[2],plus);
    printf("plus = %s",plus);

    return 0;

}