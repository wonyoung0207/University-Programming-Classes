#include <stdio.h>
#include <conio.h>
int main()
{
    int in;
    char ch;
    double dou;

    printf("input int_variable : ");
    scanf("%d", &in);
    // printf("%d", in);

    // printf("input char_variable : ");
    // scanf("%c" , &ch);
    // printf("%c", ch);

    while (getchar() != '\n');

    printf("input char_variable : ");
    scanf("%c" , &ch);

    printf("input double_variable : ");
    scanf("%lf", &dou);

    printf("\nin=%d, ch=%c, dou=%.2lf\n", in,ch,dou);
    return 0;
}