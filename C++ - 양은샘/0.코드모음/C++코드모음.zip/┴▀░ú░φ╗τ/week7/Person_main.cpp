#include <memory>
#include <iostream>

#include "Person.h"

using namespace std;

int main(){
    auto p1 = make_shared<Person>("benny",17);
    p1->disPlay("p1");
    cout << "main1 ������ p1.usecount() : " << p1.use_count() << endl;

    shared_ptr<Person> p2 = p1;
    p2->chageName("danial");

    p1->disPlay("p1");
    p2->disPlay("p2");

    cout << "main ������ p1.usecount() : " << p1.use_count() << endl;
    
    return 0;
}