#include "PizzaManager.cpp"

int main(){
    PizzaManager p;
    p.status();

    return 0;

}