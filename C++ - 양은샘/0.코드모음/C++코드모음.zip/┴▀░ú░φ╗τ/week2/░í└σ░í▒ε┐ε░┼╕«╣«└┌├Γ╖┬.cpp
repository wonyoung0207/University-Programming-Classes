#include <iostream>
#include <iomanip>
#include <typeinfo>
// #include <cmath>

using namespace std;

char list_exam(initializer_list<char> list, char find){
    char closer;
    int big=26,num;

    for(char e : list){
        num = std::abs(find - e);
        if(big > num){
            closer = e;
            big = num;
        }
    }

    //������ Ǯ�� 

    // int dist = 128;
    // char ch;

    // for(auto data : list){
    //     int diff = abs(find-data);

    //     if(dist > diff){
    //         dist = diff;
    //         ch = data;
    //     }
    // }


    return closer;
}

int main(){
    cout << "{'d','p','r','w','g','f'} ������ h�� ����� ���ڴ� : ";
    cout << list_exam({'d','p','r','w','g','f'},'h') << endl;

    cout << "{ 'k', 'q', 'b', 'r', 'a', 'e', 'v', 'z'}���� �� w�� ����� ���ڴ� : ";
    cout << list_exam({ 'k', 'q', 'b', 'r', 'a', 'e', 'v', 'z'}, 'w') << endl;

    return 0;
}