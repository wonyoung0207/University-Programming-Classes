#include <iostream>
#include <iomanip>
#include <typeinfo>
using namespace std;

auto list_exam(initializer_list<char> list, char find){
    auto closer = 0;

    for(auto e : list){
        auto result = find - e;
        if(closer > result){
            closer = result;

        }

    }

    
}

int main(){
    cout << "{'d','p','r','w','g','f'} ������ h�� ����� ���ڴ� : ";
    cout << typeid('h' - 'g').name();


    return 0;
}