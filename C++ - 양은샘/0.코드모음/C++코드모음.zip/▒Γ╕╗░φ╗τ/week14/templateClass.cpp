#include <iostream>
#include <string>
#include <cstring>

using namespace std;

template<typename T>
class Stack{
    T* ptr;
    int capacity;
    int size;
    
public:
    Stack(int capacity);
    ~Stack();
    void push(const T& element);
    T pop();
};

template<typename T>
Stack<T>::Stack(int cap): capacity(cap), size(0){
    ptr = new T[capacity];
}

template<typename T>
Stack<T>::~Stack(){
    delete [] ptr;

}


template<typename T>
T Stack<T>::pop(){
    if(size > 0){
        T temp = ptr[size -1];
        size--;
        return temp;
    }
    else{
        cout << "stack is empty" << endl;
        return 0;
    }
}

template<typename T>
void Stack<T>::push(const T& element){
    if(size < capacity){
        ptr[size] = element;
        size++;
        
    }
    else{
        cout << "stack is full" << endl;
        return;
    }
}



int main(){
    Stack<int> stack(10);
    stack.push(5);
    stack.push(6);
    stack.push(7);
    stack.push(8);

    for(int i=0; i < 5; i++){
        cout << stack.pop() << endl;
    }
    
    return 0;
    
}

