#include <iostream>
#include <string>

using namespace std;

class Account{

    int balance;//�ܾ�
    
    public:

        Account(int deposit) : balance{deposit} {};
        int getBalance() { return balance;}
        void setBalance(int deposit){
            this -> balance = deposit;
        }
        void show(){
            cout << "�ܾ��� " << balance << "�� �Դϴ�. " << endl;
        }

};

void increaseBy(Account &a, int money){//�������� a�� ���� 
    a.setBalance(a.getBalance() + money);

}


int main(){
    Account acc(500);
    int in;

    cout << "�Ա� �� " << endl;
    acc.show();

    cout << "�Աݾ� : ";
    cin >> in;

    increaseBy(acc, in);
    cout << "�Ա� ��";
    acc.show();

    return 0;
}