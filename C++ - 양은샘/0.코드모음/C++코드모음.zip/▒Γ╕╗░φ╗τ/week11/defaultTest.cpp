#include <iostream>

using namespace std;

int big(int x,int y, int z = 100){
    int k = 0;

    if(x < y){
        k = y;
    }
    else{
        k = x;
    }

    return k < z ? k : z;
}


int main(){

    int x = big(3,5);
    int y = big(300,60);
    int z = big(30,60,50);

    cout << x << ' ' << y << ' ' << z << endl;
    

    return 0;
}