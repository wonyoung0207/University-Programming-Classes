#include <iostream>

using namespace std;

int add(int *p, int size, int *q = nullptr){
    int num = 0;

    for(int i=0; i < size; i++){
        if(q == nullptr){
            num += *(p+i);
        }
        else{
            num += *(p+i) + *(q+i);
        }
        
    }

    return num;

}


int add2(int x[], int size, int y[] = nullptr){
    int num = 0;
    

    for(int i=0; i< size; i++){
        num += x[i];

        if(y == nullptr){
            return num;
        }else{
                    
        for(int k=0; k< size; k++){
                num += y[i];
            }
        }

        return num;
    }
}

int main(){
    int a[] = {1,2,3,4,5};
    int b[] = {6,7,8,9,10};
    // int *test = nullptr;

    // if(test == nullptr){
    //     cout << "nullprt" << endl;
    // }
    

    int c = add(a,sizeof(a)/sizeof(int));

    int d = add(a,sizeof(a)/sizeof(int),b);

    cout << c << endl;
    cout << d << endl;
    
    


    return 0;
}