#include <iostream>
#include <string>
#include <cmath>


using namespace std;


class Matrix{
    int arr[4];
    public:
        Matrix(int a1=0, int a2=0, int b1=0, int b2=0){
            arr[0] = a1;
            arr[1] = a2;
            arr[2] = b1;
            arr[3] = b2;
            
        };

        void show(string name);

        Matrix operator+(Matrix op2){
            Matrix tmp;
            for(int i=0; i < 4; i++){
                tmp.arr[i] = this->arr[i] + op2.arr[i];
            }

            return tmp;

        }

        Matrix& operator+=(Matrix op2){
            for(int i=0; i < 4; i++){
                this->arr[i] = this->arr[i] + op2.arr[i];
            }

            return *this;            
        }

        void operator>>(int *p){// cin�� ������ 
            for(int i=0; i < 4; i++){
                *(p+i) = this->arr[i];
            }
        }

        Matrix& operator<<(int *p){// cout�� ������
            for(int i=0; i < 4; i++){
                this->arr[i] = *(p+i);
            }

            return *this;
        }
};


void Matrix::show(string obj){
    cout << obj << "= {" << arr[0] << " " << arr[1] << " "<< arr[2] << " " << arr[3] << "} " << endl;
}

int main(){
    Matrix a(1,2,3,4), b(2,3,4,5), c;
    c = a + b;

    a.show("a");
    b.show("b");
    c.show("c");

    a += b;
    a.show("a");

    int x[4], y[4] = {5,6,7,8};
    a >> x;//a�� �� ���Ҹ� �迭 x�� ����
    b << y;//�迭 y�� ���� ���� b�� �� ���ҿ� ���� 

    cout << "x = {";
    for(int i=0; i<4; i++){
        cout << x[i] << ' ';

    }
    cout << "}" << endl;

    b.show("b");
    



    return 0;
}