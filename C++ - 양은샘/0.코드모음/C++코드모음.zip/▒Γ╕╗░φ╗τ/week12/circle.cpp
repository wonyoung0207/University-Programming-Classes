#include <iostream>
#include <string>
#include <cmath>


using namespace std;

class Circle{
    int radius;
    public:
        Circle(int r =0):radius{r}{};
        void show(string name);

        void operator++(){//���� ������ 
            this->radius++;
        }

        // // �̰͵� ���� 
        // Circle& operator++(){//���� ������ 
        //     this->radius++;
        //     return *this;
        // }

        Circle operator++(int a){//���� ������ 
            Circle tmp = *this;
            this->radius++;

            return tmp;
            
        }

        Circle operator+(int a){//+�����ڿ� ���ڸ� ������ ��� 
            Circle tmp;
            tmp.radius = this->radius + a;

            return tmp;
            
        }

};

void Circle::show(string name){
    cout << name << ") radius = " << radius << endl;
}


int main(){
    Circle a(5), b(4);
    a.show("a");
    b.show("b");


    ++a;
    a.show("a");

    b = a++;
    a.show("a");
    b.show("b");

    b = a + 3;
    b.show("b");

    
    return 0;

}