#include <iostream>
#include <string>
#include <cmath>


using namespace std;


class Power{
    int kick;
    int punch;

    public:
        Power(int kick=0, int punch=0){
            this -> kick = kick;
            this -> punch = punch;
            
        }
        
        void show(string obj);

        Power operator<<(int i){
            this->kick = this->kick * pow(2, i);
            this->punch = this->punch * pow(2, i);
        }


};


void Power::show(string obj){
    cout << obj << ") kick = " << kick << ", punch = " << punch << endl;
}


int main(){
    Power a(2,3), b(1,5);

    a << 3;
    a.show("a");

    b << 1;
    b.show("b");
    

    return 0;
}