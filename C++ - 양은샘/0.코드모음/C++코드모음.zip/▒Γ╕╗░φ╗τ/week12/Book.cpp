#include <iostream>
#include <string>
#include <cmath>


using namespace std;


class Book{
    string title;
    int price;

    public:
        Book(string t = "", int p=0) : title{t}, price{p}{};
        void show(string obj);
        string getTitle();

        void operator+=(int op2){
            this -> price = (this -> price) + op2;
            
        }

        void operator-=(int op2){
            this -> price = (this -> price) - op2;
            
        }

        bool operator==(string t){
            if(this->title == t){
                return true;
            }else{
                return false;
            }
        }

        bool operator==(int p){
            if(this->price == p){
                return true;
            }else{
                return false;
            }
        }


        bool operator==(Book op2){
            if(this->title == op2.title && this->price == op2.price){
                return true;
            }else{
                return false;
            }
        }
};



void Book::show(string obj){
    cout << obj << ") title = " << title << ", price = " << price << endl;
}



int main(){
    Book a("û��", 20000), b("�̷�", 30000);

    a += 500;
    b -= 500;
    a.show("a");
    b.show("b");

    Book c("��ǰ C++", 30000), d("��ǰ C++", 30000);

    if(c == 30000){
        cout << "��ǰ C++ ���� 30000�� " << endl;
    }

    if(c == "��ǰ C++"){
        cout << "��ǰ C++ �Դϴ�. " << endl;
    }

    if(c == d){
        cout << "�� å�� ���� å �Դϴ�. " << endl;

    }else{
        cout << "�� å�� �ٸ� å �Դϴ�. " << endl;
    }


    return 0;
}