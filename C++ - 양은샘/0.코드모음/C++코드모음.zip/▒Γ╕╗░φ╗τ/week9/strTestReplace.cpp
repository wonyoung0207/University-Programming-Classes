#include <iostream>
#include <string>

using namespace std;

int main(){

    string str1 = "that is replace test string";
    string re = "areaaa";


    str1.replace(5,re.length(), re);

    cout << str1 << endl;



    return 0;

}
