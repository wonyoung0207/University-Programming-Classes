#include <stdio.h>
#include <string.h>

int main(){
    const char str[] = "This is a long string.";
    char* p = strstr(str,"is");

    printf("%c\n", *p);
    printf("%s\n", p);

    return 0;
}

// **** ???��?����? ****
// i
// is is a long string.