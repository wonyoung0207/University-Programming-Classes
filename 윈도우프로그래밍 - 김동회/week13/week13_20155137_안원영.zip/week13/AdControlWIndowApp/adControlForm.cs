﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdControlWIndowApp
{
    public partial class adControlForm : Form
    {
        public adControlForm()
        {
            InitializeComponent();
        }

        private void nUpDown_ValueChanged(object sender, EventArgs e)
        {
            //서로의 값이 바뀌면 둘다 바뀌도록 
            tvValue.Value = (int)nUpDown.Value;
            //progress는 진행사항을 알려줌
            progress.Maximum = (int)nUpDown.Value;
            //트랙바와 업다운 컨트롤의 값으로 맥시멈 설정하면 유동적이게 됨
        }

        private void tvValue_Scroll(object sender, EventArgs e)
        {
            nUpDown.Value = tvValue.Value;
            progress.Maximum = tvValue.Value;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(progress.Value < progress.Maximum)//멕시멈보다 작을때까지만 반복 
            {
                progress.Value += 1;
            }
        }
    }
}
