package com.myspring.ahn;

public class TestModel {
	private String title;
	
	public TestModel(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	@Override
	public String toString() {
		return "TestModel [ title = "+ title + "]";
	}

}
